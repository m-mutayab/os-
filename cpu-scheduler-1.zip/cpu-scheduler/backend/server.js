const express = require("express");
const cors = require("cors");
const app = express();

app.use(cors());
app.use(express.json());

// ─── FCFS ────────────────────────────────────────────────────────────────────
app.post("/fcfs", (req, res) => {
  const processes = [...req.body.processes].sort((a, b) => a.arrival - b.arrival);
  let currentTime = 0;
  const result = processes.map((p) => {
    const start = Math.max(currentTime, p.arrival);
    const end = start + p.burst;
    currentTime = end;
    return {
      process: p.name,
      start,
      end,
      waitingTime: start - p.arrival,
      turnaroundTime: end - p.arrival,
    };
  });
  res.json(buildResponse(result));
});

// ─── SJF (Non-preemptive) ────────────────────────────────────────────────────
app.post("/sjf", (req, res) => {
  const processes = req.body.processes.map((p, i) => ({ ...p, id: i }));
  const n = processes.length;
  const done = new Array(n).fill(false);
  let currentTime = 0;
  const result = [];
  const remaining = [...processes];

  for (let count = 0; count < n; count++) {
    const available = remaining.filter(
      (p) => !done[p.id] && p.arrival <= currentTime
    );
    if (available.length === 0) {
      const next = remaining
        .filter((p) => !done[p.id])
        .sort((a, b) => a.arrival - b.arrival)[0];
      currentTime = next.arrival;
      available.push(next);
    }
    const p = available.sort((a, b) => a.burst - b.burst)[0];
    const start = currentTime;
    const end = currentTime + p.burst;
    currentTime = end;
    done[p.id] = true;
    result.push({
      process: p.name,
      start,
      end,
      waitingTime: start - p.arrival,
      turnaroundTime: end - p.arrival,
    });
  }
  res.json(buildResponse(result));
});

// ─── Priority (Non-preemptive, lower number = higher priority) ───────────────
app.post("/priority", (req, res) => {
  const processes = req.body.processes.map((p, i) => ({ ...p, id: i }));
  const n = processes.length;
  const done = new Array(n).fill(false);
  let currentTime = 0;
  const result = [];

  for (let count = 0; count < n; count++) {
    const available = processes.filter(
      (p) => !done[p.id] && p.arrival <= currentTime
    );
    if (available.length === 0) {
      const next = processes
        .filter((p) => !done[p.id])
        .sort((a, b) => a.arrival - b.arrival)[0];
      currentTime = next.arrival;
      available.push(next);
    }
    const p = available.sort((a, b) => a.priority - b.priority)[0];
    const start = currentTime;
    const end = currentTime + p.burst;
    currentTime = end;
    done[p.id] = true;
    result.push({
      process: p.name,
      start,
      end,
      waitingTime: start - p.arrival,
      turnaroundTime: end - p.arrival,
    });
  }
  res.json(buildResponse(result));
});

// ─── Round Robin ─────────────────────────────────────────────────────────────
app.post("/rr", (req, res) => {
  const quantum = req.body.quantum || 2;
  const processes = req.body.processes.map((p) => ({
    ...p,
    remaining: p.burst,
  }));

  let currentTime = 0;
  const gantt = [];
  const stats = {};
  processes.forEach((p) => {
    stats[p.name] = { arrival: p.arrival, burst: p.burst, firstRun: -1, end: 0 };
  });

  const queue = [];
  const arrived = new Set();

  // Add processes that arrive at time 0
  processes
    .filter((p) => p.arrival <= 0)
    .sort((a, b) => a.arrival - b.arrival)
    .forEach((p) => {
      queue.push(p);
      arrived.add(p.name);
    });

  if (queue.length === 0 && processes.length > 0) {
    const first = [...processes].sort((a, b) => a.arrival - b.arrival)[0];
    currentTime = first.arrival;
    queue.push(first);
    arrived.add(first.name);
  }

  while (queue.length > 0) {
    const p = queue.shift();

    if (stats[p.name].firstRun === -1) {
      stats[p.name].firstRun = currentTime;
    }

    const runTime = Math.min(p.remaining, quantum);
    gantt.push({ process: p.name, start: currentTime, end: currentTime + runTime });
    currentTime += runTime;
    p.remaining -= runTime;

    // Add newly arrived processes
    processes
      .filter((pr) => !arrived.has(pr.name) && pr.arrival <= currentTime)
      .sort((a, b) => a.arrival - b.arrival)
      .forEach((pr) => {
        queue.push(pr);
        arrived.add(pr.name);
      });

    if (p.remaining > 0) {
      queue.push(p);
    } else {
      stats[p.name].end = currentTime;
    }
  }

  const result = Object.entries(stats).map(([name, s]) => ({
    process: name,
    start: s.firstRun,
    end: s.end,
    waitingTime: s.end - s.arrival - s.burst,
    turnaroundTime: s.end - s.arrival,
  }));

  res.json({ gantt, stats: result, ...calcAvg(result) });
});

// ─── Helpers ─────────────────────────────────────────────────────────────────
function buildResponse(result) {
  return { gantt: result, stats: result, ...calcAvg(result) };
}

function calcAvg(result) {
  const avgWT =
    result.reduce((s, r) => s + r.waitingTime, 0) / result.length;
  const avgTAT =
    result.reduce((s, r) => s + r.turnaroundTime, 0) / result.length;
  return {
    avgWaitingTime: parseFloat(avgWT.toFixed(2)),
    avgTurnaroundTime: parseFloat(avgTAT.toFixed(2)),
  };
}

const PORT = 5000;
app.listen(PORT, () => console.log(`✅  CPU Scheduler API running on http://localhost:${PORT}`));
