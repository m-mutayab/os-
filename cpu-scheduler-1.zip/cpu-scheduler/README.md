# ⚙️ CPU Scheduler Simulator

A full-stack web application to simulate and visualize **4 CPU scheduling algorithms** with Gantt charts and performance statistics.

---

## 🧠 Algorithms Included

| Algorithm | Short | Description |
|-----------|-------|-------------|
| First Come First Serve | FCFS | Non-preemptive. Processes run in order of arrival. |
| Shortest Job First | SJF | Non-preemptive. Picks the process with smallest burst time next. |
| Priority Scheduling | Priority | Non-preemptive. Lower priority number = higher priority. |
| Round Robin | RR | Preemptive. Each process gets a configurable time quantum. |

---

## 📁 Project Structure

```
cpu-scheduler/
├── backend/
│   ├── server.js        ← Express API (all 4 algorithms)
│   └── package.json
├── frontend/
│   ├── public/
│   │   └── index.html
│   ├── src/
│   │   ├── App.js       ← Main React component
│   │   ├── App.css      ← Styling
│   │   └── index.js     ← React entry point
│   └── package.json
└── README.md
```

---

## ⚙️ Prerequisites

Make sure you have the following installed:

- **Node.js** v16 or higher → https://nodejs.org
- **npm** (comes with Node.js)
- A terminal / VS Code terminal

Check versions:
```bash
node -v
npm -v
```

---

## 🚀 Setup & Running

### Step 1 — Install Backend Dependencies

```bash
cd cpu-scheduler/backend
npm install
```

### Step 2 — Start the Backend Server

```bash
npm start
```

You should see:
```
✅  CPU Scheduler API running on http://localhost:5000
```

> Keep this terminal open. Open a new terminal for the next step.

---

### Step 3 — Install Frontend Dependencies

```bash
cd cpu-scheduler/frontend
npm install
```

> ⚠️ This may take 1–2 minutes the first time (React downloads ~200MB of dependencies).

### Step 4 — Start the Frontend

```bash
npm start
```

The browser will automatically open at:
```
http://localhost:3000
```

---

## 🖥️ How to Use

1. **Select an algorithm** from the top tab bar (FCFS / SJF / Priority / RR)
2. **Edit the process table** — change names, burst times, arrival times
3. For **Priority scheduling**, a Priority column appears (lower = higher priority)
4. For **Round Robin**, set the **Time Quantum** value
5. Click **▶ Simulate** to run the algorithm
6. View the **Gantt Chart** and **per-process statistics**
7. See **average waiting time** and **turnaround time** summary cards
8. Click **↺ Reset** to restore default values

---

## 🔌 API Endpoints

The backend runs on `http://localhost:5000`

### POST `/fcfs`
```json
{
  "processes": [
    { "name": "P1", "burst": 6, "arrival": 0 },
    { "name": "P2", "burst": 4, "arrival": 1 }
  ]
}
```

### POST `/sjf`
Same body as FCFS.

### POST `/priority`
```json
{
  "processes": [
    { "name": "P1", "burst": 6, "arrival": 0, "priority": 2 },
    { "name": "P2", "burst": 4, "arrival": 1, "priority": 1 }
  ]
}
```

### POST `/rr`
```json
{
  "quantum": 2,
  "processes": [
    { "name": "P1", "burst": 6, "arrival": 0 },
    { "name": "P2", "burst": 4, "arrival": 1 }
  ]
}
```

All endpoints return:
```json
{
  "gantt": [{ "process": "P1", "start": 0, "end": 6, "waitingTime": 0, "turnaroundTime": 6 }],
  "stats": [...],
  "avgWaitingTime": 2.5,
  "avgTurnaroundTime": 6.5
}
```

---

## 🛠️ Development Mode (Hot Reload)

For backend with auto-restart on file changes:
```bash
cd backend
npm run dev
```

For frontend, `npm start` already has hot reload built in.

---

## ❓ Troubleshooting

| Problem | Fix |
|---------|-----|
| `Cannot connect to backend` | Make sure backend is running on port 5000 |
| `Port 3000 already in use` | Kill other process: `npx kill-port 3000` |
| `Port 5000 already in use` | Kill other process: `npx kill-port 5000` |
| `npm install fails` | Try `npm install --legacy-peer-deps` |
| `node not found` | Install Node.js from https://nodejs.org |

---

## 📦 Tech Stack

- **Backend:** Node.js, Express, CORS
- **Frontend:** React 18, Axios
- **Styling:** Custom CSS (no UI library needed)
- **Fonts:** Inter + JetBrains Mono (Google Fonts)

---

## 📝 Notes

- All algorithms are **non-preemptive** except Round Robin
- Priority scheduling: **lower number = higher priority** (1 is highest)
- SJF breaks ties by arrival time
- The app works entirely locally — no internet required after setup (except Google Fonts)
