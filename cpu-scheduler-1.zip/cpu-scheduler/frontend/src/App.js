import React, { useState } from "react";
import axios from "axios";
import "./App.css";

const ALGORITHMS = [
  { id: "fcfs", label: "FCFS", full: "First Come First Serve", color: "#3fb6c4", desc: "Processes execute in arrival order. Simple but can cause convoy effect." },
  { id: "sjf",  label: "SJF",  full: "Shortest Job First",     color: "#8fae5d", desc: "Picks the shortest burst time next. Optimal average wait but needs future knowledge." },
  { id: "priority", label: "Priority", full: "Priority Scheduling", color: "#e8a33d", desc: "Lower priority number = higher priority. Can cause starvation." },
  { id: "rr",   label: "RR",   full: "Round Robin",            color: "#c4694f", desc: "Time-sliced fairness. Each process gets a fixed quantum turn." },
];

const PROCESS_COLORS = ["#e8a33d","#3fb6c4","#c4694f","#8fae5d","#9d8cc4","#d4708f","#6fa8c9","#c9a25e"];

const DEFAULT_PROCESSES = [
  { name: "P1", burst: 6, arrival: 0, priority: 2 },
  { name: "P2", burst: 4, arrival: 1, priority: 1 },
  { name: "P3", burst: 8, arrival: 2, priority: 3 },
  { name: "P4", burst: 3, arrival: 3, priority: 2 },
];

export default function App() {
  const [algo, setAlgo]         = useState("fcfs");
  const [processes, setProcesses] = useState(DEFAULT_PROCESSES);
  const [quantum, setQuantum]   = useState(2);
  const [result, setResult]     = useState(null);
  const [loading, setLoading]   = useState(false);
  const [error, setError]       = useState("");

  const currentAlgo = ALGORITHMS.find((a) => a.id === algo);

  const updateProcess = (i, field, val) => {
    const copy = [...processes];
    copy[i] = { ...copy[i], [field]: field === "name" ? val : Number(val) };
    setProcesses(copy);
  };

  const addProcess = () => {
    const next = `P${processes.length + 1}`;
    setProcesses([...processes, { name: next, burst: 4, arrival: processes.length, priority: 1 }]);
  };

  const removeProcess = (i) => {
    if (processes.length <= 1) return;
    setProcesses(processes.filter((_, idx) => idx !== i));
  };

  const simulate = async () => {
    setError("");
    setLoading(true);
    try {
      const payload = { processes };
      if (algo === "rr") payload.quantum = quantum;
      const { data } = await axios.post(`http://localhost:5000/${algo}`, payload);
      setResult(data);
    } catch (e) {
      setError("Cannot connect to backend. Make sure server is running on port 5000.");
    } finally {
      setLoading(false);
    }
  };

  const reset = () => {
    setResult(null);
    setError("");
    setProcesses(DEFAULT_PROCESSES);
  };

  const totalTime = result?.gantt?.length
    ? result.gantt[result.gantt.length - 1].end
    : 1;

  const colorFor = (name) => {
    const idx = processes.findIndex((p) => p.name === name);
    return PROCESS_COLORS[idx % PROCESS_COLORS.length];
  };

  return (
    <div className="app">
      {/* Header */}
      <header className="header">
        <div className="header-inner">
          <div className="logo">
            <svg className="logo-icon" viewBox="0 0 28 28" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect x="1" y="1" width="26" height="26" rx="6" stroke="currentColor" strokeWidth="1.4"/>
              <path d="M5 18 L9 18 L11.5 9 L14.5 21 L17 13 L19 18 L23 18" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" fill="none"/>
            </svg>
            <div>
              <h1>CPU Scheduler</h1>
              <p>Algorithm Simulator</p>
            </div>
          </div>
          <div className="algo-tabs">
            {ALGORITHMS.map((a) => (
              <button
                key={a.id}
                className={`tab ${algo === a.id ? "active" : ""}`}
                style={algo === a.id ? { "--tab-color": a.color } : {}}
                onClick={() => { setAlgo(a.id); setResult(null); }}
              >
                {a.label}
              </button>
            ))}
          </div>
        </div>
      </header>

      <main className="main">
        {/* Algorithm info banner */}
        <div className="algo-banner" style={{ borderLeftColor: currentAlgo.color }}>
          <span className="algo-badge" style={{ background: currentAlgo.color }}>{currentAlgo.label}</span>
          <div>
            <strong>{currentAlgo.full}</strong>
            <p>{currentAlgo.desc}</p>
          </div>
        </div>

        <div className="layout">
          {/* Left: Input Panel */}
          <section className="panel input-panel">
            <div className="panel-header">
              <h2>Process Table</h2>
              <button className="btn-icon" onClick={addProcess} title="Add process">
                <svg viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M8 3V13M3 8H13" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"/>
                </svg>
              </button>
            </div>

            <div className="table-wrap">
              <table className="process-table">
                <thead>
                  <tr>
                    <th>Name</th>
                    <th>Burst</th>
                    <th>Arrival</th>
                    {algo === "priority" && <th>Priority</th>}
                    <th></th>
                  </tr>
                </thead>
                <tbody>
                  {processes.map((p, i) => (
                    <tr key={i}>
                      <td>
                        <input
                          className="cell-input name-input"
                          value={p.name}
                          onChange={(e) => updateProcess(i, "name", e.target.value)}
                          style={{ borderColor: PROCESS_COLORS[i % PROCESS_COLORS.length] }}
                        />
                      </td>
                      <td>
                        <input
                          className="cell-input"
                          type="number" min="1"
                          value={p.burst}
                          onChange={(e) => updateProcess(i, "burst", e.target.value)}
                        />
                      </td>
                      <td>
                        <input
                          className="cell-input"
                          type="number" min="0"
                          value={p.arrival}
                          onChange={(e) => updateProcess(i, "arrival", e.target.value)}
                        />
                      </td>
                      {algo === "priority" && (
                        <td>
                          <input
                            className="cell-input"
                            type="number" min="1"
                            value={p.priority}
                            onChange={(e) => updateProcess(i, "priority", e.target.value)}
                          />
                        </td>
                      )}
                      <td>
                        <button className="btn-remove" onClick={() => removeProcess(i)}>
                          <svg viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M3.5 3.5L10.5 10.5M10.5 3.5L3.5 10.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
                          </svg>
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {algo === "rr" && (
              <div className="quantum-row">
                <label>Time Quantum</label>
                <input
                  type="number" min="1"
                  className="quantum-input"
                  value={quantum}
                  onChange={(e) => setQuantum(Number(e.target.value))}
                />
                <span className="unit">ms</span>
              </div>
            )}

            <div className="btn-row">
              <button className="btn-simulate" onClick={simulate} disabled={loading}
                style={{ background: currentAlgo.color }}>
                {loading ? (
                  "Running…"
                ) : (
                  <>
                    <svg viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path d="M3.5 2.5L11.5 7L3.5 11.5V2.5Z" fill="currentColor"/>
                    </svg>
                    Simulate
                  </>
                )}
              </button>
              <button className="btn-reset" onClick={reset}>
                <svg viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M2.5 7a4.5 4.5 0 1 1 1.3 3.18M2.5 7V3.5M2.5 7H6" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
                Reset
              </button>
            </div>

            {error && <div className="error-msg">{error}</div>}
          </section>

          {/* Right: Results Panel */}
          <section className="panel result-panel">
            {!result ? (
              <div className="empty-state">
                <svg className="empty-icon" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <rect x="6" y="26" width="8" height="16" rx="1.5" stroke="currentColor" strokeWidth="1.6"/>
                  <rect x="20" y="16" width="8" height="26" rx="1.5" stroke="currentColor" strokeWidth="1.6"/>
                  <rect x="34" y="8" width="8" height="34" rx="1.5" stroke="currentColor" strokeWidth="1.6"/>
                </svg>
                <p>Configure your processes and hit <strong>Simulate</strong> to see the Gantt chart and statistics.</p>
              </div>
            ) : (
              <>
                {/* Gantt Chart */}
                <div className="gantt-section">
                  <h2>Gantt Chart</h2>
                  <div className="gantt-scroll">
                    <div className="gantt-bar-row">
                      {result.gantt.map((item, i) => {
                        const width = ((item.end - item.start) / totalTime) * 100;
                        return (
                          <div
                            key={i}
                            className="gantt-block"
                            style={{
                              width: `${width}%`,
                              background: colorFor(item.process),
                              minWidth: "40px",
                            }}
                            title={`${item.process}: ${item.start}–${item.end}`}
                          >
                            <span className="gantt-name">{item.process}</span>
                            <span className="gantt-time">{item.end - item.start}ms</span>
                          </div>
                        );
                      })}
                    </div>
                    <div className="gantt-timeline">
                      {result.gantt.map((item, i) => (
                        <div
                          key={i}
                          className="gantt-tick"
                          style={{ left: `${(item.start / totalTime) * 100}%` }}
                        >
                          {item.start}
                        </div>
                      ))}
                      <div
                        className="gantt-tick"
                        style={{ left: "100%" }}
                      >
                        {totalTime}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Stats Table */}
                <div className="stats-section">
                  <h2>Process Statistics</h2>
                  <table className="stats-table">
                    <thead>
                      <tr>
                        <th>Process</th>
                        <th>Start</th>
                        <th>Finish</th>
                        <th>Waiting Time</th>
                        <th>Turnaround Time</th>
                      </tr>
                    </thead>
                    <tbody>
                      {result.stats.map((s, i) => (
                        <tr key={i}>
                          <td>
                            <span className="proc-dot" style={{ background: colorFor(s.process) }} />
                            {s.process}
                          </td>
                          <td>{s.start}</td>
                          <td>{s.end}</td>
                          <td>{s.waitingTime}</td>
                          <td>{s.turnaroundTime}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* Averages */}
                <div className="averages">
                  <div className="avg-card" style={{ borderTopColor: currentAlgo.color }}>
                    <div className="avg-label">Avg. Waiting Time</div>
                    <div className="avg-value" style={{ color: currentAlgo.color }}>
                      {result.avgWaitingTime} <span>ms</span>
                    </div>
                  </div>
                  <div className="avg-card" style={{ borderTopColor: currentAlgo.color }}>
                    <div className="avg-label">Avg. Turnaround Time</div>
                    <div className="avg-value" style={{ color: currentAlgo.color }}>
                      {result.avgTurnaroundTime} <span>ms</span>
                    </div>
                  </div>
                  <div className="avg-card" style={{ borderTopColor: currentAlgo.color }}>
                    <div className="avg-label">Total Time</div>
                    <div className="avg-value" style={{ color: currentAlgo.color }}>
                      {totalTime} <span>ms</span>
                    </div>
                  </div>
                </div>
              </>
            )}
          </section>
        </div>
      </main>

      <footer className="footer">
        CPU Scheduling Simulator — FCFS, SJF, Priority &amp; Round Robin
      </footer>
    </div>
  );
}
